from django.urls import path

from main.views import *

urlpatterns = [
    path('menu/', Categoryy.as_view(), name='menu'),
    path('', MainPage.as_view(), name='main'),
    path('cart/add_food/', BasketCountAdd.as_view(), name='cart_add'),
    path('cart/minus_food/', BasketCountMinus.as_view(), name='cart_minus'),
    path('add_to_cart/', AddToCart.as_view(), name='add_to_cart'),
    path('remove_from_cart/', RemoveFromCart.as_view(), name='remove_from_cart'),
    path('cart/', CartView.as_view(), name='cart'),
    path('place_order/', PlaceOrder.as_view(), name='place_order'),
    path('order_success/', OrderSuccess.as_view(), name='order_success'),
    path('order_history/', OrderHistoryView.as_view(), name='order_history'),
]
