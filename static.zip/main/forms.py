from django import forms
from main.models import Dish


class ItemCreationForm(forms.ModelForm):
    class Meta:
        model = Dish
        fields = ['name', 'description', 'price', 'count', 'category']

